def save(operator, context, **kwargs):
    raise NotImplementedError('Export of BSP data not supported!')