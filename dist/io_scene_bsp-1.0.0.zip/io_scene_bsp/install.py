import os


def modules_dir():
    return os.path.join(os.path.dirname(os.getcwd()), 'modules')


def check_dependencies():
    return os.path.exists(os.path.join(modules_dir(), 'vgio'))


def install_dependencies():
    dependency_path = os.path.join(modules_dir(), 'vgio')
    print(f'Looking for: {dependency_path}')

    if os.path.exists(dependency_path):
        return

    print('Installing package: vgio')
    import shutil

    source_path = os.path.join(os.getcwd(), 'vgio')
    shutil.copytree(source_path, dependency_path)
